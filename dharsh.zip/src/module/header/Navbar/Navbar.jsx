import React, { useContext } from "react";
import { Link } from "react-router-dom";
import "./Navbar.style.css";
import { AppContext } from "../../../context/AppContext";
import { useSelector , useDispatch } from "react-redux";
import { actions } from "../../../components/store";
import { useNavigate } from "react-router-dom";


function NavbarPage() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const isAuth = useSelector(({ auth }) => auth.isAuth);
  const { searchMovies, setSearchMovies } = useContext(AppContext);
  function getValue(event) {
    setSearchMovies(event.target.value);
  }
  function submit(event) {
    event.preventDefault();
    getValue();
  }
  function login(){
    navigate("./login")
  }
  function signup(){
    navigate("./login")
  }
  function logout(){
    dispatch(actions.authActions.logout())
  }
  return (
    <nav className="navbar pt-2  text-white">
        <Link to={"./"} className="nav-link" id="brand">
           Dharsh
        </Link>
        <div className="primary-menus  text-white">
        { isAuth && (
          <ul className="navigation-menus  text-white">
            <li className="navigation-items  text-white">
              <Link to={"./react"} className="nav-link my-2">
                Home
              </Link>
            </li>
            <li className="navigation-items  text-white">
              <Link to={"./home"} className="nav-link my-2">
                Movie
              </Link>
            </li>
            <li className="navigation-items  text-white my-2">
              <Link to={"./land"} className="nav-link">
                MovieDetails
              </Link>
            </li>
            <li className="navigation-items  text-white my-1" id="search">
              <form role="search" onSubmit={getValue}>
                <input
                  className="form-control me-2"
                  type="search"
                  placeholder="Search Movies"
                  aria-label="Search"
                  value={searchMovies}
                  onChange={getValue}
                />
              </form>
            </li>
            <li className="navigation-items  text-white my-1">
            <button className="btn btn-light" onClick={logout}>
              Logout
            </button>
          </li>
          </ul>
        )}
      </div>
      <div className="secondary-menus  text-white">
       {
        !isAuth && (
          <>
          <ul className="navigation-buttons  text-white" >
          <li className="navigation-button me-4  text-white">
            <button onClick={login} className="btn btn-light" id="login">
              Login
            </button>
          </li>
          <li className="navigation-button  text-white">
            <button onClick={signup} className="btn btn-light">
              SignUp
            </button>
          </li>
        </ul>
          </>
        )
       }
      </div>
    </nav>
  );
}

export default NavbarPage;
