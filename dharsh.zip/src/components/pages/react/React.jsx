import React from "react";
// import "./ReactPage.style.css";
import {  useSelector , useDispatch} from "react-redux";
import { actions } from "../../store";

function ReactPage() {
  const count = useSelector(({counter}) => counter.count);
  const showCount = useSelector(({counter}) => counter.showCount);
  const dispatch = useDispatch();
  const {counterActions} = actions;

  function incrementHandler() {
    dispatch(counterActions.increment());
  }
  function decrementHandler() {
    dispatch(counterActions.decrement());
  }
  function toggleShowCount() {
    dispatch(counterActions.toggle());
  }
  return (
    <div className="container mt-5 ">
      <div className="p-5 mx-auto me-5 text-center">
      <h1>Hi!!</h1>
      <h1>This is React</h1>
      </div>
    </div>
  );
}

export default ReactPage;
