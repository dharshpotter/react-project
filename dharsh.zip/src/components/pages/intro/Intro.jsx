import React from 'react'
import "./intro.style.css"

function IntroPage() {
  return (
    <div className='background'>
     <div className="container">
      <h1 className='title'>DharshMovies</h1>
     </div>
    </div>
  )
}

export default IntroPage;