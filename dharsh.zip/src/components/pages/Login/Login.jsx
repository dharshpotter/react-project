import React from "react";
import InputField from "../../../module/common/input/input";
import { useFormik } from "formik";
import { LoginSchema } from "../schema/LoginSchema";
import { Link } from "react-router-dom";
import "./Login.style.css";
import { actions } from "../../store/index";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";

function LoginPage() {
  const initialLoginStates = {
    email: "",
    password: "",
  };
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { values, errors, touched, handleBlur, handleSubmit, handleChange } =
    useFormik({
      initialValues: initialLoginStates,
      validationSchema: LoginSchema,
      onSubmit: (value, action) => {
        dispatch(actions.authActions.login(email,password));
        action.resetForm();
        navigate("/react");
      },
    });

  return (
    <div className="container mt-5" >
      <div className="card col-4 mx-auto border-0-shadow bg-dark" >
        <div className="card-body ">
          <form className="d-flex flex-column gap-3" onSubmit={handleSubmit}>
            <h4>Login</h4>
            <InputField
              type="email"
              name="email"
              label="Email"
              placeholder="Email"
              value={values.email}
              error={errors.email}
              handleBlur={handleBlur}
              handleChange={handleChange}
              touched={touched.email}
            />

            <InputField
              type="password"
              name="password"
              label="Password"
              placeholder="Password"
              value={values.password}
              error={errors.password}
              handleBlur={handleBlur}
              handleChange={handleChange}
              touched={touched.password}
            />

            <button className="btn btn-success col-4 m-auto" type="submit">
              Login
            </button>
            <p className="text-center my-0">New user?</p>
            <Link className="btn btn-danger col-10 m-auto" to="/signup">
              Create Account
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
}
export default LoginPage;
