import React, { Fragment, useState ,useEffect} from "react";
import LoaderIndicator from "../../../module/common/loaderIndicator";
import Carousel from "../../../module/common/carousel/carousel";

function HomePage() {
  const [popularMovies, setPopularMovies] = useState("");
  useEffect(() => {
    fetchPopularMovies();
  }, []);
  async function fetchPopularMovies() {
    const res = await fetch(`https://api.themoviedb.org/3/movie/popular`, {
      headers: {
        accept: "application/json",
        Authorization:
        "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIzZTMwN2Y2YjA1NGQ1NTg4YmM0ZjMwY2ExYTFjMTY0ZiIsInN1YiI6IjY1MmQwOTBlMWYzZTYwMDBhYzRmNjZjZCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.6mr1Qn9sL2XlORsYbRm8C4Rtt6zvTU_fq70o1SPvDRk",
      },
      params: {
        language: "en-US",
        page: 1,
      },   });
    const data = await res.json();
    setPopularMovies(data);
  }
  return (
    <Fragment>
      {popularMovies ? (
        <Carousel movies={popularMovies.results} />
      ) : (
        <LoaderIndicator />
      )}
    </Fragment>
  );
}

export default HomePage;
