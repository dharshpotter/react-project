import React, { useState } from "react";
import LoaderIndicator from "../../../module/common/loaderIndicator";
import { useEffect } from "react";

function LandPage() {
  const [tvShows, setTvShows] = useState("");

  useEffect(() => {
    fetchTvShows();
  }, []);

  async function fetchTvShows() {
    const res = await fetch(
      `https://api.themoviedb.org/3/trending/tv/day?query=${tvShows}language=en-US`,
      {
        headers: {
          accept: "application/json",
          Authorization:
            "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIzZTMwN2Y2YjA1NGQ1NTg4YmM0ZjMwY2ExYTFjMTY0ZiIsInN1YiI6IjY1MmQwOTBlMWYzZTYwMDBhYzRmNjZjZCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.6mr1Qn9sL2XlORsYbRm8C4Rtt6zvTU_fq70o1SPvDRk",
        },
      }
    );
    const data = await res.json();
    setTvShows(data);
  }

return (
    <div className="row row-col-2">
      {tvShows ? (
        tvShows.map((movie, i) => {         
            <div class="card" style="width: 18rem;" key={i}>
              <img src={`https://image.tmdb.org/t/p/w500${poster_path}`} class="card-img-top" alt="..." />
              <div class="card-body">
                <h5 class="card-title">{movie.name}</h5>
                <p class="card-text">{movie.overview}</p>
              </div>
            </div>         
        })
      ) : (
        <LoaderIndicator />
      )}
    
  </div>
);
      }
export default LandPage;
